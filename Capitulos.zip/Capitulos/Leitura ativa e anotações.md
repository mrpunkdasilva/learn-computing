

---
[[Metacognição e Mentalidade]] <- Anterior | Próximo -> [[Leitura difícil, boa escrita]]